import React, { useState } from "react";
function Navbar(){
   
   return(
      <>
         <nav className="nav-bar">
            <Logo />
            <SearchBar />
            <NumberResults/>
         </nav>
      </>
   )
}
function Logo(){
   return(
      <div className="logo Navlogo">
         <span role="img">🍿</span>
         <h1>usePopcorn</h1>
      </div>
   )
}
function SearchBar(){
   const [query, setQuery] = useState("");
   return(
     <>
      {/* This input type dynamic is all over website... */}
      <input type="text" placeholder="Search movies..." className="search" value={query}
      onChange={(e) => (setQuery(e.target.value))}
      />
     </>
   )
}
function NumberResults(){
   return(
      <p className="num-results">
      Found <strong>X</strong> results
   </p>
   )
}
export default Navbar;