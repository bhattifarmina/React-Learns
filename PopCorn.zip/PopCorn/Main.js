import React, { useState } from "react";
import { tempMovieData } from "./data";
import { tempWatchedData } from "./data";
function ListBox({movies}) {
   return (
      <div className="main">
         <MovieList movies={movies}/>
         <WatchData movies={movies}/>
      </div>
   )
}

function MovieList({movies}) {
   const [isOpen1, setIsOpen1] = useState(true);
   return (
      <div className="box">
         <button className="btn-toggle" onClick={() => setIsOpen1((open) => !open)}>
            {isOpen1 ? "+ " : "-"}
         </button>
         {isOpen1 && (

            <ul className="list">
               {
                  tempMovieData.map((movie) => (
                     <li key={movie.imdbID} movies={movies}>
                        <img src={movie.Poster} alt={`${movie.Title} poster`} />
                        <h3>{movie.Title}</h3>
                        <div>
                           <p>
                              <span>🗓</span>
                              <span>{movie.Year}</span>
                           </p>
                        </div>
                     </li>
                  ))
               }
            </ul>
         )}
      </div>
   )
}

function WatchData() {
   const [isOpen2, setIsOpen2] = useState(true);
   const average = (arr) =>
      arr.length === 0 ? 0 : arr.reduce((acc, cur) => acc + cur / arr.length, 0);
      const [watched, setWatched] = useState(tempWatchedData);
      const imdbRating = average(watched.map((movies) => movies.imdbRating));
      const userRating = average(watched.map((movies) => movies.userRating));
      const runtime = average(watched.map((movies)=> movies.runtime))
   return (
      <div className="box">
         <button className="btn-toggle" onClick={() => setIsOpen2((open) => !open)}>
            {isOpen2 ? "+" : "-"}
         </button>
         {isOpen2 && (
            <>
               <div className="summary">
                  <h2>Movies you watched</h2>
                  <div>
                     <p>
                        <span>#️⃣</span>
                        <span>{watched.length} movies</span>
                     </p>
                     <p>
                        <span>⭐</span>
                        <span>{imdbRating}</span>
                     </p>
                     <p>
                        <span>🌟</span>
                        <span>{userRating}</span>
                     </p>
                     <p>
                        <span>⏳</span>
                        <span>{runtime} min</span>
                     </p>
                  </div>
               </div>
               <ul className="list">
                  {
                     tempWatchedData.map((Watch) => (
                        <li key={Watch.imdbID}>
                           <img src={Watch.Poster} alt={`${Watch.Title} poster`} />
                           <h3>{Watch.Title}</h3>
                           <div>
                              <p>
                                 <span>#️⃣</span>
                                 <span>{Watch.length} movies</span>
                              </p>
                              <p>
                                 <span>⭐</span>
                                 <span>{Watch.imdbRating}</span>
                              </p>
                              <p>
                                 <span>🌟</span>
                                 <span>{Watch.userRating}</span>
                              </p>
                              <p>
                                 <span>⏳</span>
                                 <span>{Watch.runtime} min</span>
                              </p>
                           </div>
                        </li>
                     ))
                  }
               </ul>
            </>

         )}

      </div>

   )
}
export default ListBox;