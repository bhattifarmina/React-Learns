import React from "react";
import Navbar from "./Navbar";
import  "./usepopcorn.css"
import ListBox from "./Main";
// import  {tempMovieData} from "./data"
// import {tempWatchedData} from "./data"
function PopcornApp() {
   return(
      <>
         <Navbar/>
         <ListBox/>
      </>
   )
}
export default PopcornApp; 